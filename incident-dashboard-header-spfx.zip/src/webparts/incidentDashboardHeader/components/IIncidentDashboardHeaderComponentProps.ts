import { SPHttpClient } from '@microsoft/sp-http';

export interface IIncidentDashboardHeaderComponentProps {
  spHttpClient: SPHttpClient;
  siteUrl: string;
  incidentDetailsListName: string;
  signInListName: string;
  criticalInfoListName: string;
  commsListName: string;
}
