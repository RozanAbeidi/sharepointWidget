import * as React from 'react';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import styles from './IncidentDashboardHeader.module.scss';
import {
  IIncidentDashboardHeaderState,
  IIncidentDetails,
  ISignInRecord,
  IListItem
} from './IIncidentDashboardHeaderProps';
import { IIncidentDashboardHeaderComponentProps } from './IIncidentDashboardHeaderComponentProps';

const DEFAULT_INCIDENT_DETAILS: IIncidentDetails = {
  IncidentName: 'LEVEL 2 — DAWSON CREEK FEI',
  IncidentLevel: 'Level 2',
  IncidentCommander: 'Jolan Corbett',
  IncidentCommanderInitials: 'JC',
  OperationalPeriod: '19h00 — 07h00 · Started 09 14'
};

export default class IncidentDashboardHeader extends React.Component<
  IIncidentDashboardHeaderComponentProps,
  IIncidentDashboardHeaderState
> {
  constructor(props: IIncidentDashboardHeaderComponentProps) {
    super(props);
    this.state = {
      incidentDetails: undefined,
      personnelCount: 0,
      availableCount: 0,
      resourceCount: 0,
      sdaCount: 0,
      criticalInfoItems: [],
      commsItems: [],
      loading: true,
      error: undefined
    };
  }

  public componentDidMount(): void {
    this._loadData().catch((err: Error) => {
      this.setState({ loading: false, error: err.message });
    });
  }

  public componentDidUpdate(prevProps: IIncidentDashboardHeaderComponentProps): void {
    if (
      prevProps.incidentDetailsListName !== this.props.incidentDetailsListName ||
      prevProps.signInListName !== this.props.signInListName ||
      prevProps.criticalInfoListName !== this.props.criticalInfoListName ||
      prevProps.commsListName !== this.props.commsListName
    ) {
      this.setState({ loading: true, error: undefined });
      this._loadData().catch((err: Error) => {
        this.setState({ loading: false, error: err.message });
      });
    }
  }

  private async _loadData(): Promise<void> {
    const [incidentDetails, signInCounts, criticalInfoItems, commsItems] = await Promise.all([
      this._getIncidentDetails(),
      this._getSignInCounts(),
      this._getListItems(this.props.criticalInfoListName),
      this._getListItems(this.props.commsListName)
    ]);

    this.setState({
      incidentDetails,
      personnelCount: signInCounts.personnelCount,
      availableCount: signInCounts.availableCount,
      resourceCount: signInCounts.resourceCount,
      sdaCount: signInCounts.sdaCount,
      criticalInfoItems,
      commsItems,
      loading: false,
      error: undefined
    });
  }

  private async _getIncidentDetails(): Promise<IIncidentDetails> {
    try {
      const url =
        `${this.props.siteUrl}/_api/web/lists/getbytitle('${encodeURIComponent(
          this.props.incidentDetailsListName
        )}')/items?$top=1`;

      const response: SPHttpClientResponse = await this.props.spHttpClient.get(
        url,
        SPHttpClient.configurations.v1
      );

      if (!response.ok) {
        return DEFAULT_INCIDENT_DETAILS;
      }

      const data = await response.json();
      const items: IIncidentDetails[] = data.value;

      if (!items || items.length === 0) {
        return DEFAULT_INCIDENT_DETAILS;
      }

      const item = items[0] as any;

      return {
        IncidentName: item.IncidentName || DEFAULT_INCIDENT_DETAILS.IncidentName,
        IncidentLevel: item.IncidentLevel || DEFAULT_INCIDENT_DETAILS.IncidentLevel,
        IncidentCommander: item.IncidentCommander || DEFAULT_INCIDENT_DETAILS.IncidentCommander,
        IncidentCommanderInitials:
          item.IncidentCommanderInitials || this._getInitials(item.IncidentCommander) || 'IC',
        OperationalPeriod: item.OperationalPeriod || DEFAULT_INCIDENT_DETAILS.OperationalPeriod
      };
    } catch {
      return DEFAULT_INCIDENT_DETAILS;
    }
  }

  private async _getSignInCounts(): Promise<{
    personnelCount: number;
    availableCount: number;
    resourceCount: number;
    sdaCount: number;
  }> {
    try {
      const url =
        `${this.props.siteUrl}/_api/web/lists/getbytitle('${encodeURIComponent(
          this.props.signInListName
        )}')/items?$select=Title,Role,Status,ResourceCategory&$top=500`;

      const response: SPHttpClientResponse = await this.props.spHttpClient.get(
        url,
        SPHttpClient.configurations.v1
      );

      if (!response.ok) {
        return { personnelCount: 0, availableCount: 0, resourceCount: 0, sdaCount: 0 };
      }

      const data = await response.json();
      const items: ISignInRecord[] = data.value;

      const personnelCount = items.length;
      const availableCount = items.filter((i) => i.Status === 'Available').length;
      const resourceCount = items.filter((i) => i.ResourceCategory === 'Resource').length;
      const sdaCount = items.filter((i) => i.ResourceCategory === 'SDA').length;

      return { personnelCount, availableCount, resourceCount, sdaCount };
    } catch {
      return { personnelCount: 0, availableCount: 0, resourceCount: 0, sdaCount: 0 };
    }
  }

  private async _getListItems(listName: string): Promise<IListItem[]> {
    try {
      const url =
        `${this.props.siteUrl}/_api/web/lists/getbytitle('${encodeURIComponent(
          listName
        )}')/items?$select=Title,Description,Category&$top=20&$orderby=Created desc`;

      const response: SPHttpClientResponse = await this.props.spHttpClient.get(
        url,
        SPHttpClient.configurations.v1
      );

      if (!response.ok) {
        return [];
      }

      const data = await response.json();
      return data.value as IListItem[];
    } catch {
      return [];
    }
  }

  private _getInitials(name: string | undefined): string {
    if (!name) {
      return '';
    }
    return name
      .split(' ')
      .map((part) => part.charAt(0))
      .join('')
      .toUpperCase()
      .substring(0, 2);
  }

  public render(): React.ReactElement<IIncidentDashboardHeaderComponentProps> {
    const {
      incidentDetails,
      personnelCount,
      availableCount,
      resourceCount,
      sdaCount,
      criticalInfoItems,
      commsItems,
      loading,
      error
    } = this.state;

    const details = incidentDetails || DEFAULT_INCIDENT_DETAILS;

    return (
      <div className={styles.dashboardHeader}>
        <div className={styles.headerBar}>
          <div>
            <p className={styles.headerLabel}>Incident level / name</p>
            <p className={styles.headerValue}>{details.IncidentName}</p>
          </div>
          <div>
            <p className={styles.headerLabel}>Operational period</p>
            <p className={styles.headerValueRight}>{details.OperationalPeriod}</p>
          </div>
        </div>

        <div className={styles.icRow}>
          <div className={styles.icAvatar}>{details.IncidentCommanderInitials}</div>
          <div>
            <p className={styles.icName}>{details.IncidentCommander}</p>
            <p className={styles.icRole}>Incident commander</p>
          </div>
          <div
            className={`${styles.statusIndicator} ${
              error ? styles.statusError : styles.statusOk
            }`}
          >
            <span className={styles.statusDot}>&#9679;</span>
            <span>
              {loading
                ? 'Loading…'
                : error
                ? `Error loading data: ${error}`
                : 'Connected to SharePoint'}
            </span>
          </div>
        </div>

        <div className={styles.statsGrid}>
          <div className={styles.statCard}>
            <p className={styles.statLabel}>Personnel</p>
            <p className={styles.statValue}>{personnelCount}</p>
          </div>
          <div className={styles.statCard}>
            <p className={styles.statLabel}>Available</p>
            <p className={styles.statValue}>{availableCount}</p>
          </div>
          <div className={styles.statCard}>
            <p className={styles.statLabel}>Resources</p>
            <p className={styles.statValue}>{resourceCount}</p>
          </div>
          <div className={styles.statCard}>
            <p className={styles.statLabel}>SDA resources</p>
            <p className={styles.statValue}>{sdaCount}</p>
          </div>
        </div>

        <div className={styles.panelsGrid}>
          <div className={styles.panelCard}>
            <div className={styles.panelHeader}>
              <p className={styles.panelTitle}>Critical info</p>
            </div>
            {criticalInfoItems.length > 0 ? (
              <ul className={styles.panelList}>
                {criticalInfoItems.map((item, idx) => (
                  <li key={idx}>{item.Title || item.Description}</li>
                ))}
              </ul>
            ) : (
              <p className={styles.emptyState}>No critical info items configured.</p>
            )}
          </div>

          <div className={styles.panelCard}>
            <div className={styles.panelHeader}>
              <p className={styles.panelTitle}>System communications</p>
            </div>
            {commsItems.length > 0 ? (
              <ul className={styles.panelList}>
                {commsItems.map((item, idx) => (
                  <li key={idx}>{item.Title || item.Description}</li>
                ))}
              </ul>
            ) : (
              <p className={styles.emptyState}>No communications items configured.</p>
            )}
          </div>
        </div>

        <div className={styles.footerNote}>
          Personnel counts are read from the &quot;{this.props.signInListName}&quot; list
          (filtered by Status / ResourceCategory). Header fields come from &quot;
          {this.props.incidentDetailsListName}&quot;. Critical info and comms read from &quot;
          {this.props.criticalInfoListName}&quot; and &quot;{this.props.commsListName}&quot;.
        </div>
      </div>
    );
  }
}
