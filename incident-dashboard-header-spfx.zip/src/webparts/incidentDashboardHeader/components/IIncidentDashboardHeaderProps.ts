export interface IIncidentDashboardHeaderWebPartProps {
  incidentDetailsListName: string;
  signInListName: string;
  criticalInfoListName: string;
  commsListName: string;
}

export interface IIncidentDetails {
  IncidentName: string;
  IncidentLevel: string;
  IncidentCommander: string;
  IncidentCommanderInitials: string;
  OperationalPeriod: string;
}

export interface ISignInRecord {
  Title: string;
  Role: string;
  Status: string;
  ResourceCategory?: string;
}

export interface IListItem {
  Title: string;
  Description?: string;
  Category?: string;
}

export interface IIncidentDashboardHeaderState {
  incidentDetails: IIncidentDetails | undefined;
  personnelCount: number;
  availableCount: number;
  resourceCount: number;
  sdaCount: number;
  criticalInfoItems: IListItem[];
  commsItems: IListItem[];
  loading: boolean;
  error: string | undefined;
}
