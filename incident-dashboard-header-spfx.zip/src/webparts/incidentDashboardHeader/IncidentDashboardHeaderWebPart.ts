import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import IncidentDashboardHeader from './components/IncidentDashboardHeader';
import { IIncidentDashboardHeaderWebPartProps } from './components/IIncidentDashboardHeaderProps';
import { IIncidentDashboardHeaderComponentProps } from './components/IIncidentDashboardHeaderComponentProps';

export default class IncidentDashboardHeaderWebPart extends BaseClientSideWebPart<
  IIncidentDashboardHeaderWebPartProps
> {
  public render(): void {
    const element: React.ReactElement<IIncidentDashboardHeaderComponentProps> = React.createElement(
      IncidentDashboardHeader,
      {
        spHttpClient: this.context.spHttpClient,
        siteUrl: this.context.pageContext.web.absoluteUrl,
        incidentDetailsListName: this.properties.incidentDetailsListName || 'Incident Details',
        signInListName: this.properties.signInListName || 'Sign In to Incident',
        criticalInfoListName: this.properties.criticalInfoListName || 'Critical Info',
        commsListName: this.properties.commsListName || 'System Communications'
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: 'Configure the SharePoint lists used by the incident dashboard header.'
          },
          groups: [
            {
              groupName: 'List configuration',
              groupFields: [
                PropertyPaneTextField('incidentDetailsListName', {
                  label: 'Incident Details list name'
                }),
                PropertyPaneTextField('signInListName', {
                  label: 'Sign In to Incident list name'
                }),
                PropertyPaneTextField('criticalInfoListName', {
                  label: 'Critical Info list name'
                }),
                PropertyPaneTextField('commsListName', {
                  label: 'System Communications list name'
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
